import math

# First essential concept: Variables
# We define the variables radius and seconds.
radius = float(input("What is the radius of the tire?"))
seconds = float(input("What is the time in seconds it traveled for?"))

# Second essential concept: Arithmetic Operators
# We reiterate the variables via arithmetic
# operators, such as dividing.
circumference = (2 * 3.14) * radius
minutes = seconds / 60
remainder = seconds % 60
print("It traveled ", int(minutes), "minutes and ", remainder, " seconds.")
print("The tire circumference is " + str(circumference))